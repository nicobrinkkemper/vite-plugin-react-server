# RSC Worker

This directory contains the RSC worker implementation for the Vite React Server Plugin.

📖 **For full documentation, see [`../../docs/rsc-worker.md`](../../docs/rsc-worker.md)** 